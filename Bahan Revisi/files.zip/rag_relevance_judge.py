"""
================================================================================
TOOLS PENILAIAN RELEVANSI RAG (MANUAL)
================================================================================
Script untuk membantu evaluator menilai relevansi chunks yang di-retrieve
oleh sistem RAG secara manual.

Penggunaan:
1. Jalankan script: python rag_relevance_judge.py
2. Masukkan query
3. Sistem akan menampilkan top-k chunks
4. Evaluator memberikan skor 0-2 untuk setiap chunk
5. Hasil disimpan ke CSV

Author: [Nama Mahasiswa]
Version: 1.0
================================================================================
"""

import requests
import json
import csv
import os
from datetime import datetime
from typing import List, Dict, Optional


# ================================================================================
# CONFIGURATION
# ================================================================================

class Config:
    BASE_URL = "http://localhost:8000"
    CHAT_ENDPOINT = "/api/informational/v1/chat/"
    OUTPUT_DIR = "relevance_judgements"
    K_VALUES = [1, 3, 5]


# ================================================================================
# QUERY SETS
# ================================================================================

INFORMATIONAL_QUERIES = [
    {"id": "Q-I01", "query": "Berapa biaya pendaftaran SD Islam Al Azhar 27 Cibinong untuk kelas 1 Bilingual?"},
    {"id": "Q-I02", "query": "Berapa SPP bulanan SMP Al-Azhar?"},
    {"id": "Q-I03", "query": "Apakah ada biaya seragam yang harus dibayar?"},
    {"id": "Q-I04", "query": "Berapa total biaya masuk SMA Al-Azhar program reguler?"},
    {"id": "Q-I05", "query": "Ada diskon untuk anak kedua?"},
    {"id": "Q-I06", "query": "Kapan pendaftaran siswa baru dibuka?"},
    {"id": "Q-I07", "query": "Sampai kapan batas pendaftaran gelombang 1?"},
    {"id": "Q-I08", "query": "Kapan pengumuman hasil seleksi?"},
    {"id": "Q-I09", "query": "Jam berapa kantor pendaftaran buka?"},
    {"id": "Q-I10", "query": "Kapan tahun ajaran baru dimulai?"},
    {"id": "Q-I11", "query": "Apa saja dokumen yang diperlukan untuk mendaftar?"},
    {"id": "Q-I12", "query": "Berapa usia minimal masuk SD?"},
    {"id": "Q-I13", "query": "Apakah harus beragama Islam?"},
    {"id": "Q-I14", "query": "Dokumen apa yang perlu dilegalisir?"},
    {"id": "Q-I15", "query": "Apakah perlu tes masuk?"},
    {"id": "Q-I16", "query": "Apa saja fasilitas yang tersedia di sekolah?"},
    {"id": "Q-I17", "query": "Apakah ada fasilitas antar jemput?"},
    {"id": "Q-I18", "query": "Bagaimana fasilitas laboratorium komputer?"},
    {"id": "Q-I19", "query": "Apakah tersedia kantin sehat?"},
    {"id": "Q-I20", "query": "Ada fasilitas olahraga apa saja?"},
    {"id": "Q-I21", "query": "Kurikulum apa yang digunakan?"},
    {"id": "Q-I22", "query": "Apa perbedaan program reguler dan bilingual?"},
    {"id": "Q-I23", "query": "Ada program tahfidz tidak?"},
    {"id": "Q-I24", "query": "Bagaimana sistem pembelajaran di kelas?"},
    {"id": "Q-I25", "query": "Ekstrakurikuler apa saja yang tersedia?"},
]

TRANSACTIONAL_QUERIES = [
    {"id": "Q-T01", "query": "Saya ingin mendaftar ke SD Al-Azhar"},
    {"id": "Q-T02", "query": "Bagaimana cara daftar online?"},
    {"id": "Q-T03", "query": "Saya mau daftarkan anak saya ke SMP"},
    {"id": "Q-T04", "query": "Mulai proses pendaftaran"},
    {"id": "Q-T05", "query": "Daftar siswa baru SMA"},
    {"id": "Q-T06", "query": "Bagaimana cara upload dokumen?"},
    {"id": "Q-T07", "query": "Saya mau upload akta kelahiran"},
    {"id": "Q-T08", "query": "Format file apa yang diterima?"},
    {"id": "Q-T09", "query": "Dokumen saya gagal diupload"},
    {"id": "Q-T10", "query": "Cara mengganti dokumen yang sudah diupload"},
    {"id": "Q-T11", "query": "Cek status pendaftaran saya"},
    {"id": "Q-T12", "query": "Sudah sampai mana proses pendaftaran?"},
    {"id": "Q-T13", "query": "Apakah dokumen saya sudah diverifikasi?"},
    {"id": "Q-T14", "query": "Kapan saya bisa bayar?"},
    {"id": "Q-T15", "query": "Nomor registrasi saya berapa?"},
]


# ================================================================================
# RELEVANCE JUDGEMENT TOOL
# ================================================================================

class RelevanceJudgeTool:
    """Tool untuk menilai relevansi chunks secara manual"""
    
    def __init__(self):
        self.base_url = Config.BASE_URL
        self.results = []
        os.makedirs(Config.OUTPUT_DIR, exist_ok=True)
        
    def query_system(self, query: str, k: int = 5) -> Dict:
        """Query sistem RAG dan dapatkan chunks"""
        url = f"{self.base_url}{Config.CHAT_ENDPOINT}"
        payload = {
            "message": query,
            "session_id": f"judge-{datetime.now().timestamp()}",
            "top_k": k,
            "return_chunks": True  # Sesuaikan dengan API Anda
        }
        
        try:
            response = requests.post(url, json=payload, timeout=60)
            data = response.json()
            return {
                "status": response.status_code,
                "response": data.get("response", ""),
                "chunks": data.get("chunks", data.get("context", [])),
                "raw": data
            }
        except Exception as e:
            return {"status": 500, "error": str(e), "chunks": []}
    
    def display_rubric(self):
        """Tampilkan rubrik penilaian"""
        print("\n" + "="*70)
        print("RUBRIK PENILAIAN RELEVANSI")
        print("="*70)
        print("""
    Skor 2 - SANGAT RELEVAN
    Chunk berisi informasi yang langsung menjawab query secara spesifik 
    dan lengkap. Contoh: Query tentang biaya SD, chunk berisi tabel biaya SD.
    
    Skor 1 - CUKUP RELEVAN  
    Chunk berisi informasi terkait namun tidak langsung menjawab atau 
    perlu konteks tambahan. Contoh: Query biaya SD, chunk berisi info 
    umum biaya sekolah tanpa detail SD.
    
    Skor 0 - TIDAK RELEVAN
    Chunk tidak berkaitan dengan query atau berisi informasi yang salah 
    konteks. Contoh: Query biaya SD, chunk berisi info SMP.
    
    Catatan: Chunk dianggap RELEVAN jika skor >= 1
""")
        print("="*70)
    
    def judge_single_query(self, query_data: Dict, mode: str = "informational") -> Dict:
        """Proses penilaian untuk satu query"""
        query_id = query_data["id"]
        query = query_data["query"]
        
        print(f"\n{'='*70}")
        print(f"Query ID: {query_id}")
        print(f"Mode: {mode}")
        print(f"Query: {query}")
        print("="*70)
        
        # Query sistem
        result = self.query_system(query, k=5)
        chunks = result.get("chunks", [])
        
        if not chunks:
            print("\n⚠️  Tidak ada chunks yang di-retrieve!")
            print(f"Response: {result.get('response', 'N/A')[:200]}")
            return {
                "query_id": query_id,
                "query": query,
                "mode": mode,
                "chunks": [],
                "scores": [],
                "error": "No chunks retrieved"
            }
        
        # Tampilkan chunks dan minta penilaian
        scores = []
        print(f"\n📚 Retrieved Chunks ({len(chunks)}):\n")
        
        for i, chunk in enumerate(chunks[:5], 1):
            # Handle berbagai format chunk
            if isinstance(chunk, dict):
                content = chunk.get("content", chunk.get("text", str(chunk)))
                similarity = chunk.get("similarity", chunk.get("score", "N/A"))
                metadata = chunk.get("metadata", {})
            else:
                content = str(chunk)
                similarity = "N/A"
                metadata = {}
            
            print(f"\n--- Chunk {i} ---")
            print(f"Similarity Score: {similarity}")
            if metadata:
                print(f"Metadata: {json.dumps(metadata, indent=2)}")
            print(f"Content:\n{content[:500]}...")
            print("-"*50)
            
            # Minta skor dari evaluator
            while True:
                try:
                    score_input = input(f"Skor untuk Chunk {i} (0/1/2): ").strip()
                    score = int(score_input)
                    if score in [0, 1, 2]:
                        scores.append(score)
                        break
                    else:
                        print("❌ Masukkan 0, 1, atau 2!")
                except ValueError:
                    print("❌ Input tidak valid!")
        
        # Hitung metrik
        judgement = {
            "query_id": query_id,
            "query": query,
            "mode": mode,
            "chunks": chunks[:5],
            "scores": scores,
            "total_relevant": sum(1 for s in scores if s >= 1),
            "precision_at_1": self._precision_at_k(scores, 1),
            "precision_at_3": self._precision_at_k(scores, 3),
            "precision_at_5": self._precision_at_k(scores, 5),
        }
        
        print(f"\n✅ Penilaian selesai untuk {query_id}")
        print(f"   Scores: {scores}")
        print(f"   P@1: {judgement['precision_at_1']:.2%}")
        print(f"   P@3: {judgement['precision_at_3']:.2%}")
        print(f"   P@5: {judgement['precision_at_5']:.2%}")
        
        return judgement
    
    def _precision_at_k(self, scores: List[int], k: int) -> float:
        """Hitung Precision@k"""
        if k > len(scores):
            k = len(scores)
        if k == 0:
            return 0.0
        relevant = sum(1 for s in scores[:k] if s >= 1)
        return relevant / k
    
    def run_batch_judgement(self, queries: List[Dict], mode: str):
        """Jalankan penilaian batch untuk daftar query"""
        print(f"\n{'#'*70}")
        print(f"BATCH JUDGEMENT - {mode.upper()}")
        print(f"Total Queries: {len(queries)}")
        print("#"*70)
        
        self.display_rubric()
        
        input("\nTekan ENTER untuk memulai penilaian...")
        
        batch_results = []
        for i, q_data in enumerate(queries, 1):
            print(f"\n[{i}/{len(queries)}]", end="")
            result = self.judge_single_query(q_data, mode)
            batch_results.append(result)
            self.results.append(result)
            
            # Simpan progress
            self._save_progress()
            
            if i < len(queries):
                cont = input("\nLanjut ke query berikutnya? (y/n): ").strip().lower()
                if cont != 'y':
                    print("Penilaian dihentikan.")
                    break
        
        return batch_results
    
    def _save_progress(self):
        """Simpan progress ke CSV"""
        filename = f"{Config.OUTPUT_DIR}/judgement_progress_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
        
        with open(filename, 'w', newline='', encoding='utf-8') as f:
            writer = csv.writer(f)
            writer.writerow([
                "Query ID", "Query", "Mode",
                "Score 1", "Score 2", "Score 3", "Score 4", "Score 5",
                "P@1", "P@3", "P@5"
            ])
            
            for r in self.results:
                scores = r.get("scores", [])
                scores_padded = scores + [None] * (5 - len(scores))
                
                writer.writerow([
                    r["query_id"],
                    r["query"],
                    r["mode"],
                    *scores_padded,
                    f"{r.get('precision_at_1', 0):.2%}",
                    f"{r.get('precision_at_3', 0):.2%}",
                    f"{r.get('precision_at_5', 0):.2%}"
                ])
    
    def generate_final_report(self):
        """Generate laporan akhir"""
        if not self.results:
            print("Tidak ada hasil untuk di-report!")
            return
        
        filename = f"{Config.OUTPUT_DIR}/FINAL_JUDGEMENT_REPORT_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
        
        # Separate by mode
        info_results = [r for r in self.results if r["mode"] == "informational"]
        trans_results = [r for r in self.results if r["mode"] == "transactional"]
        
        with open(filename, 'w', newline='', encoding='utf-8') as f:
            writer = csv.writer(f)
            
            # Header
            writer.writerow(["LAPORAN PENILAIAN RELEVANSI RAG"])
            writer.writerow([f"Tanggal: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"])
            writer.writerow([])
            
            # Summary
            writer.writerow(["RINGKASAN"])
            writer.writerow(["Kategori", "Jumlah Query", "Avg P@1", "Avg P@3", "Avg P@5"])
            
            for mode, results in [("Informational", info_results), ("Transactional", trans_results)]:
                if results:
                    avg_p1 = sum(r.get("precision_at_1", 0) for r in results) / len(results)
                    avg_p3 = sum(r.get("precision_at_3", 0) for r in results) / len(results)
                    avg_p5 = sum(r.get("precision_at_5", 0) for r in results) / len(results)
                    writer.writerow([mode, len(results), f"{avg_p1:.2%}", f"{avg_p3:.2%}", f"{avg_p5:.2%}"])
            
            # Overall
            all_results = self.results
            if all_results:
                avg_p1 = sum(r.get("precision_at_1", 0) for r in all_results) / len(all_results)
                avg_p3 = sum(r.get("precision_at_3", 0) for r in all_results) / len(all_results)
                avg_p5 = sum(r.get("precision_at_5", 0) for r in all_results) / len(all_results)
                writer.writerow(["TOTAL", len(all_results), f"{avg_p1:.2%}", f"{avg_p3:.2%}", f"{avg_p5:.2%}"])
            
            writer.writerow([])
            
            # Detail
            writer.writerow(["DETAIL PENILAIAN"])
            writer.writerow([
                "Query ID", "Mode", "Query",
                "Chunk-1", "Chunk-2", "Chunk-3", "Chunk-4", "Chunk-5",
                "P@1", "P@3", "P@5"
            ])
            
            for r in self.results:
                scores = r.get("scores", [])
                scores_padded = scores + [""] * (5 - len(scores))
                
                writer.writerow([
                    r["query_id"],
                    r["mode"],
                    r["query"][:50] + "..." if len(r["query"]) > 50 else r["query"],
                    *scores_padded,
                    f"{r.get('precision_at_1', 0):.2%}",
                    f"{r.get('precision_at_3', 0):.2%}",
                    f"{r.get('precision_at_5', 0):.2%}"
                ])
        
        print(f"\n📊 Final Report saved: {filename}")
        return filename


# ================================================================================
# MAIN
# ================================================================================

def main():
    """Main function"""
    print("\n" + "="*70)
    print("   TOOLS PENILAIAN RELEVANSI RAG")
    print("   Sistem Chatbot YPI Al-Azhar")
    print("="*70)
    
    tool = RelevanceJudgeTool()
    
    while True:
        print("\n" + "-"*50)
        print("MENU:")
        print("1. Penilaian Query Informational (25 queries)")
        print("2. Penilaian Query Transactional (15 queries)")
        print("3. Penilaian Custom Query")
        print("4. Generate Final Report")
        print("5. Exit")
        print("-"*50)
        
        choice = input("Pilihan (1-5): ").strip()
        
        if choice == "1":
            tool.run_batch_judgement(INFORMATIONAL_QUERIES, "informational")
        
        elif choice == "2":
            tool.run_batch_judgement(TRANSACTIONAL_QUERIES, "transactional")
        
        elif choice == "3":
            query = input("Masukkan query: ").strip()
            if query:
                custom_data = {"id": f"CUSTOM-{len(tool.results)+1}", "query": query}
                mode = input("Mode (informational/transactional): ").strip().lower()
                if mode not in ["informational", "transactional"]:
                    mode = "informational"
                tool.judge_single_query(custom_data, mode)
        
        elif choice == "4":
            tool.generate_final_report()
        
        elif choice == "5":
            print("\nTerima kasih!")
            break
        
        else:
            print("❌ Pilihan tidak valid!")


if __name__ == "__main__":
    main()
