"""
================================================================================
PYTEST AUTOMATED TESTING SUITE
================================================================================
Automated test suite untuk Sistem Chatbot RAG
Jalankan dengan: pytest test_chatbot_pytest.py -v --html=report.html

Author: [Nama Mahasiswa]
Version: 1.0
================================================================================
"""

import pytest
import requests
import time
import json
from typing import Dict, Tuple
from dataclasses import dataclass


# ================================================================================
# CONFIGURATION
# ================================================================================

class TestConfig:
    BASE_URL = "http://localhost:8000"
    TIMEOUT = 30
    RAG_TIMEOUT = 60


# ================================================================================
# FIXTURES
# ================================================================================

@pytest.fixture(scope="session")
def base_url():
    """Base URL untuk API"""
    return TestConfig.BASE_URL


@pytest.fixture(scope="session")
def session_id():
    """Generate unique session ID untuk testing"""
    return f"pytest-session-{int(time.time())}"


@pytest.fixture
def api_client(base_url):
    """API Client helper"""
    class APIClient:
        def __init__(self, base_url):
            self.base_url = base_url
            
        def post(self, endpoint: str, **kwargs) -> Tuple[int, dict, float]:
            url = f"{self.base_url}{endpoint}"
            start = time.time()
            try:
                response = requests.post(url, timeout=TestConfig.TIMEOUT, **kwargs)
                elapsed = time.time() - start
                try:
                    data = response.json()
                except:
                    data = {"raw": response.text}
                return response.status_code, data, elapsed
            except Exception as e:
                return 500, {"error": str(e)}, 0
                
        def get(self, endpoint: str, **kwargs) -> Tuple[int, dict, float]:
            url = f"{self.base_url}{endpoint}"
            start = time.time()
            try:
                response = requests.get(url, timeout=TestConfig.TIMEOUT, **kwargs)
                elapsed = time.time() - start
                try:
                    data = response.json()
                except:
                    data = {"raw": response.text}
                return response.status_code, data, elapsed
            except Exception as e:
                return 500, {"error": str(e)}, 0
    
    return APIClient(base_url)


# ================================================================================
# UNIT TESTS - API ENDPOINTS
# ================================================================================

class TestUnitAPI:
    """Unit Tests untuk API Endpoints"""
    
    def test_ut01_upload_valid_pdf(self, api_client):
        """UT-01: Upload file PDF valid harus berhasil"""
        files = {"file": ("test.pdf", b"%PDF-1.4 test", "application/pdf")}
        status, data, _ = api_client.post("/documents/upload", files=files)
        assert status == 200, f"Expected 200, got {status}: {data}"
    
    def test_ut02_upload_invalid_format(self, api_client):
        """UT-02: Upload file format tidak valid harus ditolak"""
        files = {"file": ("test.exe", b"invalid", "application/octet-stream")}
        status, data, _ = api_client.post("/documents/upload", files=files)
        assert status in [400, 415, 422], f"Expected 400/415/422, got {status}"
    
    def test_ut03_process_document_valid(self, api_client):
        """UT-03: Process dokumen dengan ID valid"""
        status, data, _ = api_client.post("/documents/1/process")
        assert status in [200, 404], f"Expected 200 or 404, got {status}"
    
    def test_ut04_process_document_not_found(self, api_client):
        """UT-04: Process dokumen dengan ID tidak ada harus 404"""
        status, data, _ = api_client.post("/documents/999999/process")
        assert status == 404, f"Expected 404, got {status}"
    
    def test_ut05_process_chunks(self, api_client):
        """UT-05: Process pending chunks"""
        status, data, _ = api_client.post("/chunks/process-pending?limit=10")
        assert status == 200, f"Expected 200, got {status}"
    
    def test_ut06_generate_embeddings(self, api_client):
        """UT-06: Generate embeddings"""
        status, data, _ = api_client.post("/embed/?limit=100")
        assert status == 200, f"Expected 200, got {status}"
    
    def test_ut07_chat_informational_valid(self, api_client, session_id):
        """UT-07: Chat informational dengan query valid"""
        payload = {"message": "Berapa biaya pendaftaran?", "session_id": session_id}
        status, data, _ = api_client.post("/api/informational/v1/chat/", json=payload)
        assert status == 200, f"Expected 200, got {status}"
        assert "response" in data or "message" in data
    
    def test_ut08_chat_informational_empty(self, api_client, session_id):
        """UT-08: Chat informational tanpa query harus error"""
        payload = {"message": "", "session_id": session_id}
        status, data, _ = api_client.post("/api/informational/v1/chat/", json=payload)
        assert status in [400, 422], f"Expected 400/422, got {status}"
    
    def test_ut09_chat_transactional_valid(self, api_client, session_id):
        """UT-09: Chat transactional dengan session"""
        payload = {"message": "Saya ingin mendaftar", "session_id": session_id}
        status, data, _ = api_client.post("/api/transactional/v1/chat/", json=payload)
        assert status == 200, f"Expected 200, got {status}"
    
    def test_ut10_chat_transactional_no_session(self, api_client):
        """UT-10: Chat transactional tanpa session harus error"""
        payload = {"message": "Test"}
        status, data, _ = api_client.post("/api/transactional/v1/chat/", json=payload)
        assert status in [400, 422], f"Expected 400/422, got {status}"


# ================================================================================
# INTEGRATION TESTS
# ================================================================================

class TestIntegration:
    """Integration Tests untuk alur sistem"""
    
    @pytest.fixture(autouse=True)
    def setup(self):
        """Setup untuk setiap test"""
        self.session_id = f"integration-{int(time.time())}"
    
    def test_it01_init_session(self, api_client):
        """IT-01: Inisialisasi session baru"""
        payload = {"message": "Halo", "session_id": self.session_id}
        status, data, _ = api_client.post("/api/transactional/v1/chat/", json=payload)
        assert status == 200
        assert data.get("response") or data.get("message")
    
    def test_it02_select_school(self, api_client):
        """IT-02: Pemilihan sekolah tujuan"""
        payload = {"message": "SD Islam Al Azhar Cibinong", "session_id": self.session_id}
        status, data, _ = api_client.post("/api/transactional/v1/chat/", json=payload)
        assert status == 200
    
    def test_it03_input_valid_data(self, api_client):
        """IT-03: Input data siswa valid"""
        payload = {
            "message": "Nama: Test User, Tanggal Lahir: 2018-01-01",
            "session_id": self.session_id
        }
        status, data, _ = api_client.post("/api/transactional/v1/chat/", json=payload)
        assert status == 200
    
    def test_it04_upload_valid_document(self, api_client):
        """IT-04: Upload dokumen valid"""
        files = {"file": ("akta.pdf", b"%PDF-1.4 akta", "application/pdf")}
        status, data, _ = api_client.post("/documents/upload", files=files)
        assert status == 200
    
    def test_it05_upload_invalid_document(self, api_client):
        """IT-05: Upload dokumen tidak valid harus ditolak"""
        files = {"file": ("virus.exe", b"malware", "application/octet-stream")}
        status, data, _ = api_client.post("/documents/upload", files=files)
        assert status in [400, 415, 422]


# ================================================================================
# FUNCTIONAL TESTS - INFORMATIONAL
# ================================================================================

class TestFunctionalInformational:
    """Functional Tests untuk mode informational"""
    
    @pytest.fixture(autouse=True)
    def setup(self):
        self.session_id = f"func-info-{int(time.time())}"
    
    @pytest.mark.parametrize("query,expected_topic", [
        ("Berapa biaya pendaftaran SD Al-Azhar?", "biaya"),
        ("Kapan pendaftaran dibuka?", "jadwal"),
        ("Apa saja persyaratan mendaftar?", "persyaratan"),
        ("Fasilitas apa saja yang tersedia?", "fasilitas"),
        ("Kurikulum apa yang digunakan?", "kurikulum"),
    ])
    def test_informational_queries(self, api_client, query, expected_topic):
        """FT-INFO: Query informational harus mendapat respons"""
        payload = {"message": query, "session_id": self.session_id}
        status, data, response_time = api_client.post(
            "/api/informational/v1/chat/", 
            json=payload
        )
        
        assert status == 200, f"Query '{query}' failed with {status}"
        assert data.get("response") or data.get("message"), "No response received"
        assert response_time < 10, f"Response too slow: {response_time}s"
    
    def test_out_of_context_query(self, api_client):
        """FT-OOC: Query di luar konteks harus ditangani"""
        payload = {"message": "Siapa presiden Indonesia?", "session_id": self.session_id}
        status, data, _ = api_client.post("/api/informational/v1/chat/", json=payload)
        
        assert status == 200
        # Should indicate out of scope
        response_text = str(data.get("response", "")).lower()
        # Check if response indicates limitation (sesuaikan dengan behavior sistem)
    
    def test_typo_handling(self, api_client):
        """FT-TYPO: Sistem harus menangani typo"""
        payload = {"message": "brpa biaya pendaftrn?", "session_id": self.session_id}
        status, data, _ = api_client.post("/api/informational/v1/chat/", json=payload)
        
        assert status == 200
        assert data.get("response") or data.get("message")


# ================================================================================
# FUNCTIONAL TESTS - TRANSACTIONAL
# ================================================================================

class TestFunctionalTransactional:
    """Functional Tests untuk mode transactional"""
    
    @pytest.fixture(autouse=True)
    def setup(self):
        self.session_id = f"func-trans-{int(time.time())}"
    
    def test_start_registration(self, api_client):
        """FT-REG: Memulai proses pendaftaran"""
        payload = {"message": "Saya ingin mendaftar", "session_id": self.session_id}
        status, data, _ = api_client.post("/api/transactional/v1/chat/", json=payload)
        
        assert status == 200
        assert data.get("response") or data.get("message")
    
    def test_check_status(self, api_client):
        """FT-STATUS: Cek status pendaftaran"""
        payload = {"message": "Cek status pendaftaran", "session_id": self.session_id}
        status, data, _ = api_client.post("/api/transactional/v1/chat/", json=payload)
        
        assert status == 200


# ================================================================================
# PERFORMANCE TESTS - RAG
# ================================================================================

class TestRAGPerformance:
    """Performance Tests untuk RAG system"""
    
    @pytest.fixture(autouse=True)
    def setup(self):
        self.session_id = f"rag-perf-{int(time.time())}"
    
    def test_response_time_under_5s(self, api_client):
        """PERF-TIME: Response time harus di bawah 5 detik"""
        payload = {"message": "Berapa biaya pendaftaran?", "session_id": self.session_id}
        status, data, response_time = api_client.post(
            "/api/informational/v1/chat/", 
            json=payload
        )
        
        assert response_time < 5.0, f"Response time {response_time}s exceeds 5s limit"
    
    def test_response_has_content(self, api_client):
        """PERF-CONTENT: Response harus memiliki konten"""
        payload = {"message": "Apa saja fasilitas sekolah?", "session_id": self.session_id}
        status, data, _ = api_client.post("/api/informational/v1/chat/", json=payload)
        
        response_text = data.get("response", data.get("message", ""))
        assert len(response_text) > 50, "Response too short"
    
    @pytest.mark.parametrize("query", [
        "Biaya pendaftaran SD",
        "Jadwal pendaftaran",
        "Persyaratan dokumen",
        "Kurikulum sekolah",
        "Fasilitas olahraga",
    ])
    def test_retrieval_returns_results(self, api_client, query):
        """PERF-RETRIEVAL: Retrieval harus mengembalikan hasil"""
        payload = {
            "message": query, 
            "session_id": self.session_id,
            "return_chunks": True
        }
        status, data, _ = api_client.post("/api/informational/v1/chat/", json=payload)
        
        assert status == 200
        # Check if response contains meaningful content


# ================================================================================
# CUSTOM MARKERS & CONFIGURATIONS
# ================================================================================

def pytest_configure(config):
    """Register custom markers"""
    config.addinivalue_line("markers", "slow: marks tests as slow")
    config.addinivalue_line("markers", "rag: marks tests related to RAG")
    config.addinivalue_line("markers", "api: marks tests for API endpoints")


# ================================================================================
# CONFTEST ALTERNATIVE - Jika menggunakan conftest.py terpisah
# ================================================================================

"""
# Simpan di conftest.py untuk shared fixtures:

import pytest

@pytest.fixture(scope="session")
def base_url():
    return "http://localhost:8000"

@pytest.fixture(scope="session") 
def session_id():
    import time
    return f"pytest-{int(time.time())}"
"""
