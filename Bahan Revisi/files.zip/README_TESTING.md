# 📋 Dokumentasi Sistem Pengujian Chatbot RAG

## Deskripsi
Kumpulan script dan tools untuk melakukan pengujian komprehensif pada Sistem Chatbot berbasis Large Language Model dengan Retrieval Augmented Generation (RAG) untuk YPI Al-Azhar Jakarta.

## 📁 Struktur File

```
testing/
├── testing_system.py           # Script utama pengujian (Unit, Integration, Functional, RAG)
├── test_chatbot_pytest.py      # Test suite berbasis pytest untuk automated testing
├── rag_relevance_judge.py      # Tool manual untuk penilaian relevansi RAG
├── requirements_testing.txt    # Dependencies Python
└── README.md                   # Dokumentasi ini
```

## 🛠️ Instalasi

### 1. Install Dependencies
```bash
pip install -r requirements_testing.txt
```

### 2. Konfigurasi
Edit konfigurasi di masing-masing file:
```python
# testing_system.py
class Config:
    BASE_URL = "http://localhost:8000"  # Sesuaikan dengan URL backend Anda
```

## 🚀 Cara Penggunaan

### A. Pengujian Otomatis (testing_system.py)

Script ini menjalankan semua jenis pengujian secara berurutan:
- Unit Testing (10 test cases)
- Integration Testing (8 test cases)
- Functional Testing (12 test cases)
- RAG Performance Testing

```bash
# Pastikan backend sudah running
python testing_system.py
```

**Output:**
- `hasil_pengujian/hasil_pengujian.csv` - Detail semua test cases
- `hasil_pengujian/rag_metrics.csv` - Metrik RAG (Precision, Recall)
- `hasil_pengujian/ringkasan_pengujian.txt` - Ringkasan hasil

### B. Pytest Automated Testing (test_chatbot_pytest.py)

Untuk testing dengan pytest framework:

```bash
# Run semua tests
pytest test_chatbot_pytest.py -v

# Generate HTML report
pytest test_chatbot_pytest.py -v --html=report.html

# Run specific test class
pytest test_chatbot_pytest.py::TestUnitAPI -v

# Run dengan coverage
pytest test_chatbot_pytest.py --cov=. --cov-report=html
```

### C. Penilaian Relevansi Manual (rag_relevance_judge.py)

Tool interaktif untuk evaluator menilai relevansi chunks:

```bash
python rag_relevance_judge.py
```

**Menu:**
1. Penilaian Query Informational (25 queries)
2. Penilaian Query Transactional (15 queries)
3. Penilaian Custom Query
4. Generate Final Report
5. Exit

**Rubrik Penilaian:**
| Skor | Kategori | Kriteria |
|------|----------|----------|
| 2 | Sangat Relevan | Chunk langsung menjawab query secara spesifik dan lengkap |
| 1 | Cukup Relevan | Chunk terkait tapi tidak langsung menjawab |
| 0 | Tidak Relevan | Chunk tidak berkaitan dengan query |

## 📊 Query Sets

### Informational Queries (25 total)
- Biaya (5 queries): Q-I01 s/d Q-I05
- Jadwal (5 queries): Q-I06 s/d Q-I10
- Persyaratan (5 queries): Q-I11 s/d Q-I15
- Fasilitas (5 queries): Q-I16 s/d Q-I20
- Kurikulum (5 queries): Q-I21 s/d Q-I25

### Transactional Queries (15 total)
- Pendaftaran (5 queries): Q-T01 s/d Q-T05
- Upload (5 queries): Q-T06 s/d Q-T10
- Status (5 queries): Q-T11 s/d Q-T15

## 📈 Metrik yang Diukur

### Unit Testing & Functional Testing
- Pass Rate: Persentase test case yang berhasil
- Response Time: Waktu respons per request

### RAG Performance
- **Precision@k**: Proporsi dokumen relevan dalam top-k hasil
  ```
  Precision@k = (Jumlah chunk relevan dalam top-k) / k
  ```
- **Recall@k**: Proporsi dokumen relevan yang berhasil di-retrieve
  ```
  Recall@k = (Jumlah chunk relevan dalam top-k) / (Total chunk relevan)
  ```
- **Response Quality**: Skor 1-5 untuk Relevance, Accuracy, Completeness

## 🎯 Target Keberhasilan

| Metrik | Target | Prioritas |
|--------|--------|-----------|
| Unit Test Pass Rate | 100% | Wajib |
| Integration Test Pass Rate | 100% | Wajib |
| Functional Test Pass Rate | 100% | Wajib |
| Precision@3 | ≥ 90% | Wajib |
| Recall@3 | ≥ 85% | Wajib |
| Response Quality (avg) | ≥ 4.0/5.0 | Direkomendasikan |
| Response Time | < 3 detik | Direkomendasikan |

## ⚠️ Catatan Penting

1. **Pastikan Backend Running**: Semua script memerlukan backend API aktif
2. **Sesuaikan Endpoint**: Edit `Config.ENDPOINTS` jika struktur API berbeda
3. **Timeout**: Default 30 detik, bisa disesuaikan di `Config.TIMEOUT`
4. **Manual Judgement**: Untuk hasil akurat, gunakan `rag_relevance_judge.py` dengan evaluator manusia

## 🔧 Troubleshooting

### Connection Error
```
Error: Connection refused
```
**Solusi**: Pastikan backend server sudah running di URL yang dikonfigurasi

### Timeout Error
```
Error: Request timeout
```
**Solusi**: Tingkatkan `REQUEST_TIMEOUT` atau periksa performa server

### No Chunks Retrieved
```
Warning: Tidak ada chunks yang di-retrieve
```
**Solusi**: Periksa knowledge base sudah ter-embed dan threshold similarity

## 📝 Contoh Output

### Ringkasan Pengujian
```
======================================================================
RINGKASAN HASIL PENGUJIAN SISTEM CHATBOT RAG
======================================================================

1. UNIT TESTING
   Total Test Case  : 10
   Passed           : 10
   Failed           : 0
   Pass Rate        : 100.0%

2. RAG PERFORMANCE
   Informational:
   - Avg Precision@3 : 100.00%
   - Avg Recall@3    : 96.00%

   TOTAL:
   - Avg Precision@3 : 100.00%
   - Avg Recall@3    : 95.00%

Status: ✓ LULUS - Semua kriteria terpenuhi
======================================================================
```

## 👤 Author
[Nama Mahasiswa]
Program Studi Teknik Informatika
Universitas Al-Azhar Indonesia
2026
